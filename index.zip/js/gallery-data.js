const portfolioItems = [
    { title: "حملة اتصالات", desc: "تصميم وتنفيذ بوثات ومطبوعات", image: "assets/images/etisalat.jpg" },
    { title: "هدايا سامسونج", desc: "أطقم هدايا VIP للموظفين", image: "assets/images/samsung.jpg" },
    { title: "مؤتمر فايزر", desc: "تجهيز القاعات والمواد الدعائية", image: "assets/images/pfizer.jpg" },
    { title: "يونيفورم BUC", desc: "توريد ملابس الطلبة والموظفين", image: "assets/images/buc.jpg" },
    // ضيف مشاريعك هنا بنفس الطريقة
];