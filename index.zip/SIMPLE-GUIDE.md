# 🧒 دليل الطفل - خطوات بسيطة للنشر

---

## ✅ **المرحلة 1: تجهيز الملفات (أنت هنا الآن)**

### **الخطوة 1️⃣: حمّل كل الملفات**

**افتح المجلد اللي فيه:**
```
C:\xampp\htdocs\NewMoon_V1.1 HTML
```

**حمّل الملفات دي من outputs/ واستبدل القديم:**

**ملفات HTML (10 ملفات):**
- ✅ index.html (الصفحة الرئيسية)
- ✅ nav.html (القائمة)
- ✅ products.html (المنتجات)
- ✅ services.html (الخدمات)
- ✅ portfolio.html (الأعمال)
- ✅ companies.html (الشركات)
- ✅ about.html (من نحن)
- ✅ faq.html (الأسئلة)
- ✅ testimonials.html (آراء العملاء)

**ملفات SEO (2 ملفات):**
- ✅ sitemap.xml (حطه في الـ root)
- ✅ robots.txt (حطه في الـ root)

**ملفات توثيق (3 ملفات - للقراءة فقط):**
- 📖 DOMAIN-SETUP.md
- 📖 CHECKLIST.md
- 📖 NEXT_STEPS.md

---

## ✅ **المرحلة 2: رفع الملفات على الإنترنت**

### **الخطوة 2️⃣: افتح الـ Hosting**

**لو عندك cPanel:**
1. افتح المتصفح
2. روح على: `https://yourdomain.com/cpanel`
3. اكتب Username و Password
4. دوس Login

---

### **الخطوة 3️⃣: ارفع الملفات**

**في cPanel:**

**أ. روح File Manager:**
```
اضغط على أيقونة "File Manager"
```

**ب. افتح المجلد:**
```
اضغط على مجلد "public_html"
```

**ج. احذف القديم (لو موجود):**
```
اختار كل الملفات القديمة
→ Delete
→ Confirm
```

**د. ارفع الجديد:**
```
1. اضغط زر "Upload" فوق
2. اختار كل الملفات من مجلدك المحلي
3. انتظر لحد ما يخلص الرفع
4. لما يخلص، ارجع للـ File Manager
```

**هـ. تأكد إن الملفات موجودة:**
```
المفروض تشوف:
public_html/
  ├── index.html
  ├── products.html
  ├── services.html
  ├── ... (باقي الملفات)
  ├── sitemap.xml
  ├── robots.txt
  ├── css/
  ├── assets/
  └── js/
```

---

## ✅ **المرحلة 3: ربط الدومين**

### **الخطوة 4️⃣: ربط newmoonadv.com**

**في cPanel:**

**أ. روح Domains:**
```
اضغط على "Domains" في القائمة
```

**ب. إضافة الدومين:**
```
اضغط "Create A New Domain"
→ Domain: اكتب newmoonadv.com
→ Document Root: /public_html
→ اضغط Submit
```

---

### **الخطوة 5️⃣: Redirect الدومينات الباقية**

**في cPanel → Domains → Redirects:**

**Redirect 1:**
```
Type: Permanent (301)
https://: مختار
www.: اختياري
Domain: newmoonadv.shop
Redirects to: https://newmoonadv.com
www. redirection: Only redirect with www.
Wild Card: مش مختار
→ Add
```

**كرر نفس الخطوة لـ:**
- newmoonadv.net → https://newmoonadv.com
- newmoonadv.store → https://newmoonadv.com

---

## ✅ **المرحلة 4: تأمين الموقع (HTTPS)**

### **الخطوة 6️⃣: تفعيل SSL**

**في cPanel:**

**أ. روح SSL/TLS Status:**
```
Security → SSL/TLS Status
```

**ب. فعّل AutoSSL:**
```
اختار newmoonadv.com
→ اضغط "Run AutoSSL"
→ انتظر دقيقة
→ لما يظهر ✅ يبقى خلاص
```

---

## ✅ **المرحلة 5: Google (اختياري - لكن مهم)**

### **الخطوة 7️⃣: Google Search Console**

**أ. افتح:**
```
https://search.google.com/search-console/
```

**ب. Add Property:**
```
→ اضغط "Add Property"
→ اختار "URL prefix"
→ اكتب: https://newmoonadv.com
→ Continue
```

**ج. Verify (اختار طريقة):**

**الطريقة الأسهل - HTML file:**
```
1. حمّل ملف التحقق (مثلاً: google123abc.html)
2. في cPanel → File Manager
3. ارفع الملف في public_html/
4. ارجع لـ Google → اضغط Verify
```

**د. Submit Sitemap:**
```
في Search Console:
→ Sitemaps (من القائمة الجانبية)
→ Add new sitemap
→ اكتب: sitemap.xml
→ Submit
```

---

### **الخطوة 8️⃣: Google Analytics**

**✅ تم بالفعل!**
```
الكود موجود في index.html
ID: G-MQD95TNNBC
مش محتاج تعمل حاجة
```

**لو عايز تشوف الإحصائيات:**
```
1. روح https://analytics.google.com/
2. اختار Property: New Moon Website
3. شوف التقارير
```

---

## ✅ **المرحلة 6: الاختبار**

### **الخطوة 9️⃣: اختبر الموقع**

**أ. افتح المتصفح:**
```
اكتب: https://newmoonadv.com
→ المفروض الموقع يفتح
```

**ب. اختبر الصفحات:**
```
✓ اضغط على المنتجات
✓ اضغط على الخدمات
✓ اضغط على تواصل معنا
✓ جرب زرار WhatsApp
```

**ج. اختبر على الموبايل:**
```
افتح الموقع من موبايلك
تأكد إنه شكله كويس
```

---

## ✅ **المرحلة 7: الصيانة**

### **الخطوة 🔟: متابعة دورية**

**كل أسبوع:**
```
✓ افتح Google Analytics
✓ شوف عدد الزوار
✓ شوف أكثر صفحة بيزوروها
```

**كل شهر:**
```
✓ افتح Google Search Console
✓ شوف Impressions & Clicks
✓ اختبر سرعة الموقع
```

---

## 🆘 **لو حصلت مشكلة**

### **المشكلة: الموقع مش بيفتح**
```
✓ تأكد إنك رفعت الملفات في public_html/
✓ تأكد إن الدومين متربط صح
✓ انتظر ساعة وجرب تاني
✓ امسح Cache المتصفح (Ctrl + Shift + Del)
```

### **المشكلة: الصور مش ظاهرة**
```
✓ تأكد إنك رفعت مجلد assets/
✓ تأكد إن المسارات صح
```

### **المشكلة: HTTPS مش شغال**
```
✓ فعّل SSL من cPanel
✓ انتظر 10 دقائق
✓ امسح Cache وجرب تاني
```

---

## 📞 **محتاج مساعدة؟**

**اتصل بالـ Hosting Support:**
```
✓ اسألهم عن SSL
✓ اسألهم عن Domain Setup
✓ اسألهم عن File Upload
```

**أو ابعتلي سكرين شوت للمشكلة** 📸

---

## 🎉 **مبروك!**

**لو وصلت هنا يبقى الموقع شغال!** 🎊

**شارك الموقع:**
- Facebook: https://www.facebook.com/61569383031991
- Instagram: https://www.instagram.com/new_moonagency
- WhatsApp: 01280081544

---

**✅ انتهى الدليل**
